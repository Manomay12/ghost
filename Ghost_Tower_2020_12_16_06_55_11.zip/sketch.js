var b,bi
var ghost, gi
var doorgroup
var door
function preload(){
  bi=loadImage("tower.png") 
  gi=loadImage("ghost-jumping.png")
  doo=loadImage("door.png") 
}

function setup(){
 createCanvas (500,600) 
 b=createSprite(250,300,500,600)
 b.addImage("b",bi)
  b.velocityY=2
  
  ghost=createSprite(250,200,20,20)
  ghost.addImage("g", gi)
  ghost.scale=0.4
  ghost.velocityY=5
  
  doorgroup=new Group()
}
function draw(){
 background("green") 
                
   if(b.y>600){
    b.y=300
  }
  
  if(keyDown("space")){
    ghost.velocityY=-5
  }
   if (keyDown("LEFT_ARROW")) {
  ghost.x=ghost.x-10 
 }
 if (keyDown("RIGHT_ARROW")) {
 ghost.x=ghost.x+10 
 }        
if  (ghost.istouching(door)){
  ghost.collide(door)
  }
  
  
  ghost.velocityY=ghost.velocityY+0.5
  doors();  
 drawSprites() ;
}


function doors(){
  if (frameCount%60===0){
     door=createSprite(random(10,490),20,20,20)
     door.addImage("do", doo)
    door.velocityY=3
doorgroup.add(door)    
 }
}



